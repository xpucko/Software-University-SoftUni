class Guild:
    def __init__(self, name: str):
        self.name = name
        self.players = []

    def assign_player(self, player: Player):
        result = f'Welcome player {player.name} to the guild {self.name}'

        if player in self.players:
            result = f'Player {player.name} is already in the guild.'
        if player.guild != 'Unaffiliated':
            result = f'Player {player.name} is in another guild.'
        else:
            self.players.append(player)
            player.guild = self.name

        return result

    def kick_player(self, player_name: str):
        result = f'Player {player_name} is not in the guild.'

        if player_name in [x.name for x in self.players]:
            player = [p for p in self.players if p.name == player_name][0]
            self.players.remove(player)
            result = f'Player {player_name} has been removed from the guild.'

        return result

    def guild_info(self):
        result = f'Guild: {self.name}\n'

        for name in self.players:
            result += name.player_info()

        return result
